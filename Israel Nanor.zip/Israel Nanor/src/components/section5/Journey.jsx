function Journey() {
  return <></>;
}
export default Journey;
